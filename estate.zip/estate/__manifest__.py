{
	'name':'Real Estate',
	'category':'sales',
	'application':True,
	'data': [
        'security/ir.model.access.csv',
		'views/estate_menus.xml',
		'views/estate_property_views.xml',
        ],
}
